"""HTTP API + frontend. Starlette app; run with `python -m larpcheck serve`."""
from __future__ import annotations

import asyncio
import json
import queue as _queue
from pathlib import Path

from starlette.applications import Starlette
from starlette.middleware.cors import CORSMiddleware
from starlette.requests import Request
from starlette.responses import FileResponse, JSONResponse, StreamingResponse
from starlette.routing import Mount, Route
from starlette.staticfiles import StaticFiles

from .config import ROOT, settings
from .db import DB
from .queue import JobManager

FRONTEND = ROOT / "frontend"
db = DB()
jobs = JobManager(db)


async def index(_: Request):
    return FileResponse(FRONTEND / "index.html")


async def create_test(request: Request):
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "invalid JSON"}, status_code=400)
    text = (body.get("text") or body.get("query") or "").strip()
    if not text:
        return JSONResponse({"error": "text is required (CA, X link, or a sentence with both)"}, status_code=400)
    if len(text) > 2000:
        return JSONResponse({"error": "too long"}, status_code=400)
    res = jobs.submit(text, source="web", requester=request.client.host if request.client else "",
                      force=bool(body.get("force")), ca=body.get("ca"), x_url=body.get("x_url"))
    return JSONResponse(res, status_code=202 if res["status"] != "done" else 200)


async def get_test(request: Request):
    row = db.get(request.path_params["tid"], full=True)
    if not row:
        return JSONResponse({"error": "not found"}, status_code=404)
    return JSONResponse(row)


async def stream_test(request: Request):
    """Server-sent events for live progress."""
    tid = request.path_params["tid"]
    row = db.get(tid, full=False)
    if not row:
        return JSONResponse({"error": "not found"}, status_code=404)
    q: "_queue.Queue[dict]" = _queue.Queue()
    backlog = jobs.subscribe(tid, q.put)

    async def gen():
        try:
            for ev in backlog:
                yield f"data: {json.dumps(ev)}\n\n"
            if row["status"] in ("done", "error"):
                yield f"data: {json.dumps({'kind': 'done', 'status': row['status']})}\n\n"
                return
            while True:
                try:
                    ev = q.get_nowait()
                except _queue.Empty:
                    await asyncio.sleep(0.5)
                    if await request.is_disconnected():
                        return
                    yield ": ping\n\n"
                    continue
                yield f"data: {json.dumps(ev)}\n\n"
                if ev.get("kind") == "done":
                    return
        finally:
            jobs.unsubscribe(tid, q.put)

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


async def lookup(request: Request):
    """Has this CA / handle already been tested?"""
    key = request.query_params.get("key", "").strip()
    if not key:
        return JSONResponse({"error": "key required"}, status_code=400)
    row = db.latest_for_key(key, done_only=False)
    return JSONResponse({"found": bool(row), "test": row})


async def archive(request: Request):
    p = request.query_params
    rows = db.archive(q=p.get("q", ""), verdict=p.get("verdict", ""),
                      limit=min(int(p.get("limit", 50)), 200), offset=int(p.get("offset", 0)))
    return JSONResponse({"tests": rows, "stats": db.stats()})


async def live(_: Request):
    return JSONResponse({"rooms": jobs.live()})


async def status(_: Request):
    return JSONResponse({"ok": True, **jobs.status(), "model": settings.MODEL, "mock": settings.MOCK_LLM,
                         "budget_per_test_usd": settings.BUDGET_USD_PER_TEST})


routes = [
    Route("/", index),
    Route("/api/tests", create_test, methods=["POST"]),
    Route("/api/tests/{tid}", get_test),
    Route("/api/tests/{tid}/stream", stream_test),
    Route("/api/lookup", lookup),
    Route("/api/archive", archive),
    Route("/api/status", status),
    Route("/api/live", live),
    Mount("/static", StaticFiles(directory=str(FRONTEND)), name="static"),
]

app = Starlette(routes=routes)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


def serve() -> None:
    import uvicorn
    print(f"LarpCheck on http://localhost:{settings.PORT}  (workers={settings.WORKERS}, model={settings.MODEL}, mock={settings.MOCK_LLM})")
    uvicorn.run(app, host=settings.HOST, port=settings.PORT, log_level="info")
